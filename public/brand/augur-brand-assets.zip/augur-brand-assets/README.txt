Augur brand assets
==================

Every file here is a supplied master. Use it as it is: do not redraw,
recolor, stretch, rotate or add effects. Files named "navy" use Augur
Navy #0E0E21; there is no true black in the palette.

Logo
  horizontal/  The primary lockup. Use it wherever it fits. At least 150 px wide.
  vertical/    A fallback for narrow, square or centered spaces. At least 93 px tall.
  glyph/       Only where the name Augur is already on the surface. At least 50 px tall.
  rep-token/   The canonical REP token icon. Keep its navy circle.

Variants
  color     Default on Paper #F5F5F8 and White #FFFFFF
  reversed  Default on Navy #0E0E21 and Raised #242438
  navy      One tint, for supporting roles on light surfaces
  white     One tint, for supporting roles on dark surfaces

Clearspace
  Use the lowercase "a" of the wordmark as the unit: one a-width clear on
  the left and right, one a-height above and below.

Core palette
  Augur Navy    #0E0E21
  Augur Green   #2AE7A8   (use Deep #095E42 for green text on light surfaces)
  Augur Paper   #F5F5F8
  Raised        #242438
  Augur Pewter  #A1A1B8

Typefaces
  Sora               Primary: identity, display, headings, controls
  Schibsted Grotesk  Secondary: paragraphs, metadata, dense text
  Both are available from Google Fonts under the SIL Open Font License 1.1.

Questions about using the Augur name or marks: see Contact on augur.net.
